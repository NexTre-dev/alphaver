Texture Pack made by Bolternon#1825

Make sure you place either Programmer Art or any Alpha/Beta MC texture pack below this one, as not all Alpha textures are currently present in this pack as of now.

Warden skin shown in this pack is a placeholder. Also Lilypad Revision is the alphaver pack to end all alphaver packs. Shoutouts to RetroGamingNow!